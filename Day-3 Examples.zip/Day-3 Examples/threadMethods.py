import imp
from threading import *
print(current_thread().getName())
current_thread().setName("excelr")
print(current_thread().getName())



