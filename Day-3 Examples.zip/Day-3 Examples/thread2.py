from threading import *
import threading

def display():
	for i in range(1,11):
		print("child thread")

t=Thread(target=display)
t.start()#starting a thread 
for i in range(1,11):
		print("main thread")