try:
    result = 12 / 0
    print("Result is", result)#error code
except ZeroDivisionError:
    print("dont enter zero as denominator")
print("remaining 1000 lines code ")
#system defined error messages
#abnormal termination


#normal ternimation
#user friendly error message 












