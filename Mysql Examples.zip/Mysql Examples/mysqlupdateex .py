
import mysql.connector

mydb=mysql.connector.connect(host="localhost",user="root",passwd="rpsconsulting",database="excelr_weekend")

mycursor=mydb.cursor()

mycursor.execute("update excelr_emps set ename='sandeep' where empid=125");

mydb.commit();