
import mysql.connector

mydb=mysql.connector.connect(host="localhost",user="root",passwd="rpsconsulting",database="excelr_weekend")

mycursor=mydb.cursor()

mycursor.execute("delete from excelr_emps where empid=125");

mydb.commit();