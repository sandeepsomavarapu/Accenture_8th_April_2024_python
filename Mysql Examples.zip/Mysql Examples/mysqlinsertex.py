
import mysql.connector

mydb=mysql.connector.connect(host="localhost",user="root",passwd="rpsconsulting",database="excelr_weekend")

mycursor=mydb.cursor()

mycursor.execute("insert into excelr_emps values(127,'rajesh')");

mydb.commit();